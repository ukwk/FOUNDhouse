![FOUNDhouse](http://foundhouse.cc/assets/img/header.PNG)

FOUNDhouse
==========

an open source, digitally fabricated microhouse  (http://foundhouse.cc)  
an open project built on wikihouse (http://wikihouse.cc)  
created by Patrick Beseda and Lacy Williams of FNDRY (http://fndryfndry.com)

3D Files
==========
Included
*.3dm (Rhino)
*.skp (SketchUp)
*.stl

2D Files
==========
Will add 2D cut sheets in *.skp, *.dwg, *.pdf, and *.3dm
